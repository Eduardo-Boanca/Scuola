
public class GenerateFactorial {
    // private int MAX_RAND_NUM = 1000;
    // private int MIN_RAND_NUM = 0;
    private int numRand = (int) Math.floor(Math.random() * (Main.MAX_RAND_NUM - Main.MIN_RAND_NUM + 1));

    public int getNumRand() {
        return numRand;
    }
}
