public class CoinToss {
    public static int coinToss() {
        return (int) Math.round(Math.random());
    }
}
